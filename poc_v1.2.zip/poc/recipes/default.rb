
include_recipe 'poc::rhelpackages'
include_recipe 'poc::user'
include_recipe 'poc::directory'
include_recipe 'poc::script'
